package com.birdview

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment

import com.birdview.models.BirdHotspot
import com.example.birdview.R
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

import kotlinx.coroutines.delay

import kotlin.math.roundToInt

@Suppress("NAME_SHADOWING", "DEPRECATION")
class MapsFragment : Fragment(), OnMapReadyCallback, GoogleMap.OnMarkerClickListener{


    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback
    private val Base_Url = "https://api.ebird.org/v2/"
    private lateinit var dbRef: DatabaseReference

    // private lateinit var binding: ActivityMapsBinding
    private lateinit var btnCurrentLocation: ImageView


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_maps, container, false)

        btnCurrentLocation = view.findViewById(R.id.btnCurrentLocation)
        dbRef = FirebaseDatabase.getInstance().getReference("Users")

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = childFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this.requireActivity())
        getUserData()
        getLocationUpdates()

        btnCurrentLocation.setOnClickListener {
            setUpMap()
        }
        return view
    }

    //Get bird hotspots from api
    private fun getBirdHotspots(location: LatLng) {
        val apiKey = "nf54v0llfda1" // Your API key here
        //hotspots around the phone current location, Durban
        val hotspots = listOf(
            BirdHotspot(latitude = -29.866458, longitude = 31.016815, locationName = "Durban--Wilsons Wharf 1"),
            BirdHotspot(latitude = -29.863347, longitude = 31.022103, locationName = "Durban--Royal Natal Yacht Club Wharf"),
            BirdHotspot(latitude = -29.847214, longitude = 31.006679, locationName = "Durban--Botanical Gardens"),
            BirdHotspot(latitude = -29.869148, longitude = 31.043061, locationName = "Durban--Point area"),
            BirdHotspot(latitude = -29.867357, longitude = 30.975125, locationName = "Durban--UKZN Sports Complex"),
            BirdHotspot(latitude = -29.918526, longitude = 31.014490, locationName = "Durban--Bluff National Park Golf Club") ,
            BirdHotspot(latitude = -29.905618, longitude = 30.939560, locationName = "Durban--Kenneth Stainbank NR") ,
            BirdHotspot(latitude = -29.816186, longitude = 31.016350, locationName = "Durban--Burman Bush NR") ,
            BirdHotspot(latitude = -29.810263, longitude = 31.037750, locationName = "Durban--Umgeni River Mouth") ,
            BirdHotspot(latitude = -29.836288, longitude = 30.942800, locationName = "Westville--Nature Trail") ,
            BirdHotspot(latitude = -29.840477, longitude = 30.925137, locationName = "Westville--Eco Trail") ,
            BirdHotspot(latitude = -29.841872, longitude = 30.910742, locationName = "Westville--Jubilee Park") ,
            BirdHotspot(latitude = -29.959815, longitude = 30.965562, locationName = "Durban--Mondi Merebank"),
            //BirdHotspots around the current location,San Fracisco, Mountain View
            BirdHotspot(latitude = 37.422575, longitude = -122.082165, locationName = "70 Bird Species(Moorhen*) , Charleston Park"),
            BirdHotspot(latitude = 37.418608, longitude = -122.080785, locationName = "58 Bird Species(African Robin*), Google Green Loop"),
            BirdHotspot(latitude = 37.427434, longitude = -122.086269, locationName = "147 Bird Species(Great Tit*),Permanente Creek Trail"),
            BirdHotspot(latitude = 37.431017, longitude = -122.095066, locationName = "143 Bird Species(Brent Goose*), Shoreline Park-Road"),
            BirdHotspot(latitude = 37.428628, longitude = -122.081320, locationName = "126 Bird Species(Blackbird*), Shoreline Park-Area"),
            BirdHotspot(latitude = 37.416960, longitude = -122.089348, locationName = "31 Bird Species(Brent Goose*), Sierra Vista Park-Mountain View"),
            BirdHotspot(latitude = 37.455800, longitude = -122.102800, locationName = "95 Bird Species(Grey Heron*), Stevens Creek Trail"),
            BirdHotspot(latitude = 37.401374, longitude = -122.108204, locationName = "82 Bird Species(Mute Swan*), McClellan Ranch Preserve"),
            BirdHotspot(latitude = 37.429278, longitude = -122.102019, locationName = "110 Bird Species(Blue Tit*), Rengstorff Park"),
            BirdHotspot(latitude = 37.469017, longitude = -122.170469, locationName = "65 Bird Species(Goldfinch*), Windy Hill Open Space Preserve"),
            BirdHotspot(latitude = 37.480850, longitude = -122.226217, locationName = "85 Bird Species(American Bald Eagle*), Edgewood Park"),
            BirdHotspot(latitude = 37.411975, longitude = -122.045450, locationName = "120 Bird Species(Woodpecker*), Rancho San Antonio Preserve"),
            BirdHotspot(latitude = 37.474091, longitude = -122.112717, locationName = "76 Bird Species(Song Thrush*), Palo Alto Baylands Nature Preserve"),
            BirdHotspot(latitude = 37.482246, longitude = -122.115832, locationName = "132 Bird Species(Brent Goose*), Byxbee Park"),
            BirdHotspot(latitude = 37.484730, longitude = -122.202133, locationName = "90 Bird Species(American Robin*), Huddart Park"),
            BirdHotspot(latitude = 37.491845, longitude = -122.229546, locationName = "55 Bird Species, Pulgas Ridge Open Space Preserve"),
            BirdHotspot(latitude = 37.394695, longitude = -122.079565, locationName = "89 Bird Species, Arastradero Preserve"),
            BirdHotspot(latitude = 37.457154, longitude = -122.213896, locationName = "120 Bird Species, Jasper Ridge Biological Preserve"),

            //Dublin, Ireland
        BirdHotspot(latitude = 53.343790, longitude = -6.257430, locationName = "42 Bird Species, St Stephen's Green Park, Moorhen"),
        BirdHotspot(latitude = 53.347600, longitude = -6.259510, locationName = "68 Bird Species, Phoenix Park, European Robin"),
        BirdHotspot(latitude = 53.335580, longitude = -6.329400, locationName = "57 Bird Species, Memorial Gardens, Great Tit"),
        BirdHotspot(latitude = 53.362200, longitude = -6.233320, locationName = "91 Bird Species, Bull Island Nature Reserve, Brent Goose"),
        BirdHotspot(latitude = 53.347500, longitude = -6.266700, locationName = "33 Bird Species, Dublin Castle, Blackbird"),
        BirdHotspot(latitude = 53.349800, longitude = -6.264400, locationName = "47 Bird Species, Ha'penny Bridge Area, Grey Heron"),
        BirdHotspot(latitude = 53.340590, longitude = -6.271440, locationName = "59 Bird Species, Grand Canal Dock, Mute Swan"),
        BirdHotspot(latitude = 53.357990, longitude = -6.251620, locationName = "82 Bird Species, National Botanic Gardens, Blue Tit"),
        BirdHotspot(latitude = 53.370180, longitude = -6.305310, locationName = "64 Bird Species, Tolka Valley Park, Goldfinch"),
        BirdHotspot(latitude = 53.365310, longitude = -6.216940, locationName = "85 Bird Species, North Bull Island, Curlew"),
        BirdHotspot(latitude = 53.353180, longitude = -6.238120, locationName = "41 Bird Species, Fairview Park, Song Thrush"),
        BirdHotspot(latitude = 53.318810, longitude = -6.279660, locationName = "71 Bird Species, Herbert Park, Woodpigeon")


        )

        hotspots.forEach { hotspot ->
            val location = LatLng(hotspot.latitude ?: 0.0, hotspot.longitude ?: 0.0)
            placeMarkerOnMap(location, hotspot.locationName ?: "Hotspot")
        }
    }

     suspend fun getMapRange(): Float{
        var distance = 50f //default value for map range incase user has not set their preference yet
        val user = FirebaseAuth.getInstance().currentUser
        dbRef.child(user?.uid.toString()).child("Settings").child("mapRangePreference").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")
            if (it.value != null){
               distance = it.value.toString().toFloat()
            }

        }.addOnFailureListener{
            Log.e("firebase", "Error getting data", it)
        }

        dbRef.child(user?.uid.toString()).child("Settings").child("unitMeasurement").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value}")
            if (it.exists()){
                if (it.value!!.toString() == "imperial"){
                    //convert distance to imperial
                    distance = distance *1.60934f

                }
            }
        }.addOnFailureListener{
            Log.e("firebase", "Error getting data", it)
        }

        delay(2000)
        return distance
    }
    /********************************************************************************************/
    /** implemented map members */
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.setOnMarkerClickListener(this)
        setUpMap()

    }
    private fun placeMarkerOnMap(currentLatLng: LatLng, locatioName: String) {
        val markerOptions = MarkerOptions().position(currentLatLng)
        markerOptions.title(locatioName)
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN))
        mMap.addMarker(markerOptions)
    }

    private fun placeMarkerOnMap(currentLatLng: LatLng, locatioName: String, num: Int) {
        val markerOptions = MarkerOptions().position(currentLatLng)
        markerOptions.title("$locatioName")
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
        mMap.addMarker(markerOptions)
    }

    private fun placeMarkerOnMap(currentLatLng: LatLng, num: Int) {
        val markerOptions = MarkerOptions().position(currentLatLng)
        markerOptions.title("My location")
        mMap.addMarker(markerOptions)
    }

    override fun onMarkerClick(marker: Marker): Boolean
    {
        showDirectionsDialog(marker.title.toString(), marker.position)

        return false
    }

    /********************************************************************************************/
    private fun setUpMap(){

        if (ActivityCompat.checkSelfPermission(this.requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this.requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this.requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }

        fusedLocationProviderClient.lastLocation
            .addOnSuccessListener {
                if (it != null) {
                    val location = LatLng(it.latitude, it.longitude)

                    placeMarkerOnMap(location, 0)
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location, 15F))

                    getBirdHotspots(location)
                }else{
                    Toast.makeText(this.requireContext(), "Cannot get location.", Toast.LENGTH_SHORT).show()
                }

            }

        }

    /********************************************************************************************/
    /** Location updates methods**/
    private fun getLocationUpdates()
    {


        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this.requireContext())
        locationRequest = LocationRequest()
        locationRequest.interval = 50000
        locationRequest.fastestInterval = 50000
        locationRequest.smallestDisplacement = 170f // 170 m = 0.1 mile
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY //set according to your app function
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult?) {
                locationResult ?: return

                if (locationResult.locations.isNotEmpty()) {
                    // get latest location
                    val location =
                        locationResult.lastLocation

                }


            }
        }
    }

    //start location updates
    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(
                this.requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this.requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        fusedLocationProviderClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            null /* Looper */
        )
    }
    private fun getUserData(){
        try{
            val user = FirebaseAuth.getInstance().currentUser
            val database = FirebaseDatabase.getInstance()
            val databaseReference = database.getReference("Users")
            databaseReference.child(user?.uid.toString()).get().addOnSuccessListener {
                if(it.exists()){
                    for(obsr in it.child("observations").children){
                        //code attribution
                        //the following code was taken from Stack Overflow and adapted
                        //https://stackoverflow.com/questions/38232140/how-to-get-the-key-from-the-value-in-firebase
                        //Frank van Puffelen
                        //https://stackoverflow.com/users/209103/frank-van-puffelen

                        val latitude = obsr.child("latitude").getValue(String::class.java)
                        val longitude = obsr.child("longitude").getValue(String::class.java)

                        placeMarkerOnMap(LatLng(latitude!!.toDouble(), longitude!!.toDouble()), "My observation",  0)
                    }
                }
            }.addOnCompleteListener(){
                if (it.isComplete){

                }
                else{
                    Toast.makeText(context, "User data retrieval failed.", Toast.LENGTH_SHORT).show()
                }
            }.addOnFailureListener(){
                Toast.makeText(context, "Failure", Toast.LENGTH_SHORT).show()
            }
        }
        catch(ex : Exception){
            Toast.makeText(context, ex.message, Toast.LENGTH_SHORT).show()
        }
    }
    // stop location updates
    private fun stopLocationUpdates() {
        fusedLocationProviderClient.removeLocationUpdates(locationCallback)
    }

    // stop receiving location update when activity not visible/foreground
    override fun onPause() {
        super.onPause()
        stopLocationUpdates()
    }

    // start receiving location update when activity  visible/foreground
    override fun onResume() {
        super.onResume()
        startLocationUpdates()
    }
    /********************************************************************************************/

    private fun showDirectionsDialog(place: String, destination: LatLng){
        var source: LatLng? = null

        val dialog = Dialog(requireContext())
        dialog.show()
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.attributes.windowAnimations = R.style.DialogAnimation
        dialog.window!!.setGravity(Gravity.BOTTOM)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.directions_bottom_sheet_layout)

        val getDirections = dialog.findViewById<Button>(R.id.btnGetDirections)
        val locationName = dialog.findViewById<TextView>(R.id.txtLocationName)
        val displayDistance = dialog.findViewById<TextView>(R.id.txtDistance)

        locationName.text = place

        if (place.equals("My location")){
            getDirections.isVisible = false
        }

        if (ActivityCompat.checkSelfPermission(this.requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this.requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this.requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }

        //the following code was taken and adapted from StackOverflow
        //https://stackoverflow.com/questions/6981916/how-to-calculate-distance-between-two-locations-using-their-longitude-and-latitu
        //author: sandeepmaaram
        //https://stackoverflow.com/users/2720929/sandeepmaaram
        fusedLocationProviderClient.lastLocation
            .addOnSuccessListener {
                if (it != null) {
                    source = LatLng(it.latitude, it.longitude)
                    val src = Location("source")
                    val dest = Location("destination")
                    src.set(it)
                    dest.latitude = destination.latitude
                    dest.longitude = destination.longitude
                    val distance = (src).distanceTo(dest) * 0.001 //convert to kilometers
                    displayDistance.text = "${distance.roundToInt()}km away"
                }else{
                    Toast.makeText(this.requireContext(), "Cannot get location.", Toast.LENGTH_SHORT).show()
                }

            }


        getDirections.setOnClickListener {

            /*var uri = Uri.parse("https://www.google.com/maps/dir/$source/$destination")
            var intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
*/

            val gmmIntentUri =
                Uri.parse("google.navigation:q=${destination!!.latitude},${destination!!.longitude}")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)
            dialog.dismiss()
        }

    }

}






