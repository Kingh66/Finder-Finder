package com.birdview.models

//code attribution
//the following code was taken from Android Developer and adapted
//https://developer.android.com/codelabs/basic-android-kotlin-training-lists#2
//Android Developer
data class User(var email : String? = null, var name : String? = null,
                var signUpDate : String? = null, var profilePicture: String? = null)

