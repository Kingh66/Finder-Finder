package com.birdview

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.MediaPlayer
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.birdview.adapters.BirdListAdapter
import com.birdview.api_interfaces.EBirdApiService
import com.birdview.api_interfaces.FlickrService
import com.birdview.api_interfaces.XenoCantoService
import com.birdview.models.Bird
import com.birdview.models.BirdWithImage
import com.example.birdview.R
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class AddSightingFragment(private val fragmentManager : FragmentManager, private val tripId: String?) : Fragment() {
    private lateinit var newRecyclerView : RecyclerView
    companion object {
        private const val REQUEST_LOCATION_PERMISSION = 101
    }
    private val coroutineScope = CoroutineScope(Dispatchers.Main)

    private lateinit var text : TextView
    private lateinit var prgLoad : ProgressBar
    private lateinit var cardViewUnidentified : CardView
    private lateinit var cardViewManualEntry : CardView
    private lateinit var currentLatLng : LatLng
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_add_sighting, container, false)

        text = view.findViewById<TextView>(R.id.imgBird)
        prgLoad = view.findViewById(R.id.prgLoad)
        cardViewUnidentified = view.findViewById(R.id.cardViewUnidentified)
        cardViewManualEntry = view.findViewById(R.id.cardViewManualSighting)
        text.setText(null)
        newRecyclerView = view.findViewById(R.id.rvObservations)
        newRecyclerView.layoutManager = LinearLayoutManager(view.context)
        newRecyclerView.setHasFixedSize(true)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this.requireContext())

        mediaPlayer = MediaPlayer()
        checkLocationPermissions()

        //val tripId = arguments?.getString("tripId")
        cardViewUnidentified.setOnClickListener{
            val childFragment = UnidentifiedDialogFragment(currentLatLng.latitude.toString(), currentLatLng.longitude.toString(), tripId)
            childFragment.show(fragmentManager, UnidentifiedDialogFragment::class.java.simpleName)
        }

        cardViewManualEntry.setOnClickListener(){
            val childFragment = BirdManualEntryDialogFragment(currentLatLng.latitude.toString(), currentLatLng.longitude.toString(), tripId)
            childFragment.show(fragmentManager, BirdManualEntryDialogFragment::class.java.simpleName)
        }

        return view
    }

    fun checkLocationPermissions() {
        if (ContextCompat.checkSelfPermission(this.requireContext(), android.Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this.requireContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED){
            // Location permissions have not been granted; request them
            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_LOCATION_PERMISSION)
        } else {
            // Location permissions have been granted; you can proceed with location-related tasks
            // e.g., start location updates
            val location = fusedLocationProviderClient.lastLocation
            location.addOnSuccessListener {
                if (it != null) {
                    currentLatLng = LatLng(it.latitude, it.longitude)

                    findBirds(it.latitude, it.longitude)
                    //       placeMarkerOnMap(currentLatLng)
                    //     mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15F))
                }
            }
        }
    }


    @SuppressLint("MissingPermission")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                val location = fusedLocationProviderClient.lastLocation
            location.addOnSuccessListener {
                if (it != null) {
                    val currentLatLng = LatLng(it.latitude, it.longitude)
                    Toast.makeText(
                        context,
                        it.latitude.toString() + it.longitude.toString(),
                        Toast.LENGTH_SHORT
                    ).show()
                    findBirds(it.latitude, it.longitude)
                    //       placeMarkerOnMap(currentLatLng)
                    //     mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15F))
                }
            }
            } else {
                Toast.makeText(context, "Cannot get your location.", Toast.LENGTH_SHORT).show()
            }
        }
    }


    fun findBirds(latitude : Double, longitude: Double){
        try{
            val retrofit = Retrofit.Builder()
                .baseUrl("https://api.ebird.org/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            val eBirdApiService = retrofit.create(EBirdApiService::class.java)
            var apiKey = "p7epg6jpkgis" // Replace with your eBird API key

            val call =
                eBirdApiService.getBirdObservations(latitude, longitude, 10, 30, 30, "json", apiKey)
            val newArrayList = arrayListOf<BirdWithImage>()
            call.enqueue(object : Callback<List<Bird>> {
                override fun onResponse(
                    call: Call<List<Bird>>,
                    response: Response<List<Bird>>
                ) {
                    if (response.isSuccessful) {
                        val observations = response.body()
                        if (observations != null) {
                            for (obs in observations) {
                                newArrayList.add(
                                    BirdWithImage(
                                        obs.speciesCode,
                                        obs.comName,
                                        obs.sciName,
                                        null,
                                        null
                                    )
                                )
                            }
                        }
                        searchImagesByText(newArrayList, latitude, longitude)

                    } else {
                        Toast.makeText(context, "Error processing birds", Toast.LENGTH_SHORT).show()
                        // Handle error
                    }

                    //displayData()
                }

                override fun onFailure(call: Call<List<Bird>>, t: Throwable) {
                    Toast.makeText(context, "Error processing birds "+t.message, Toast.LENGTH_SHORT).show()
                }
            })
        }
        catch(e: Exception){
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }
    fun searchImagesByText(newArrayList: ArrayList<BirdWithImage>, latitude : Double, longitude: Double) {

        try{
            val apiKey = "d53d32be5b38ab4a962a8f7f433a5d57"
            val flickrService = Retrofit.Builder()
                .baseUrl("https://api.flickr.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(FlickrService::class.java)
            val deferredList = ArrayList<Deferred<Any>>() // Use Deferred<Any> to handle both success and failure

//            val coroutineScope = CoroutineScope(Dispatchers.Main)

            for (i in 0 until newArrayList.size) {
                val flickrCall = flickrService.searchPhotos(apiKey = apiKey, text = newArrayList[i].sciName)

                val deferred = coroutineScope.async(Dispatchers.IO) {
                    try {
                        val response = flickrCall.execute()

                        if (response.isSuccessful) {
                            val flickrResponse = response.body()

                            val imageUrls = flickrResponse?.photos?.photo?.map { photo ->
                                "https://farm${photo.farm}.staticflickr.com/${photo.server}/${photo.id}_${photo.secret}_m.jpg"
                            }

                            if (imageUrls != null && imageUrls.isNotEmpty()) {
                                newArrayList[i].url = imageUrls.first()
                            }

                            // Return a success indicator
                            Unit
                        } else {
                            // Handle Flickr API error
                            Toast.makeText(context, "Error: ${response.code()}", Toast.LENGTH_SHORT).show()
                            // Return the error as an exception
                            throw RuntimeException("Flickr API error: ${response.code()}")
                        }
                    } catch (t: Throwable) {
                        // Handle network error
                        Toast.makeText(context, "Network Error: ${t.message}", Toast.LENGTH_SHORT).show()
                        // Return the error as an exception
                        throw t
                    }
                }

                deferredList.add(deferred)
            }

            coroutineScope.launch {
                deferredList.awaitAll()

                // Check for any errors
                if (deferredList.any { it.isCompleted && it.getCompleted() is Throwable }) {
                    // Handle errors if needed
                    Toast.makeText(context, "Some requests failed", Toast.LENGTH_SHORT).show()
                }
                searchRecordings(newArrayList, latitude, longitude)

            }
        }
        catch(e:Exception){
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    fun searchRecordings(newArrayList: ArrayList<BirdWithImage>, latitude : Double, longitude: Double){
        try{
            val xenoCantoService = Retrofit.Builder()
                .baseUrl("https://xeno-canto.org/api/2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(XenoCantoService::class.java)
            val deferredList = ArrayList<Deferred<Any>>() // Use Deferred<Any> to handle both success and failure


            coroutineScope.launch {
                for (i in 0 until newArrayList.size) {
                    val xenoCantoCall =
                        xenoCantoService.getRecordings(query = "gen:${newArrayList[i].sciName}")

                    val deferred = async(Dispatchers.IO) {
                        try {
                            val response = xenoCantoCall.execute()

                            if (response.isSuccessful) {
                                val recordings = response.body()

                                if ((recordings?.numRecordings ?: 0) > 0) {
                                    // Assuming you want to use the first recording URL
                                    newArrayList[i].recording = recordings!!.recordings[0].file
                                } else {
                                    Toast.makeText(
                                        context,
                                        "No recordings found for the specified bird.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                                // Return success
                                Unit
                            } else {
                                Toast.makeText(
                                    context,
                                    "Error ${response.code()}",
                                    Toast.LENGTH_SHORT
                                ).show()
                                // Return the error code
                                response.code()
                            }
                        } catch (t: Throwable) {
                            Toast.makeText(context, " Error ${t.message}", Toast.LENGTH_SHORT)
                                .show()
                            // Return the exception
                            t
                        }
                    }

                    deferredList.add(deferred)

                    // Introduce a delay of 1 second between requests
                    delay(1000)
                }

                deferredList.awaitAll()

                // Check for any errors
                if (deferredList.any { it.isCompleted && it.getCompleted() is Throwable }) {
                    // Handle errors if needed
                    Toast.makeText(context, "Some requests failed", Toast.LENGTH_SHORT).show()
                }

                // All requests completed (with or without errors)
                newRecyclerView.adapter = BirdListAdapter(
                    newArrayList,
                    latitude.toString(),
                    longitude.toString(),
                    fragmentManager,
                    tripId,
                    mediaPlayer
                )
                //code attribution
                //the following code was taken from Stack Overflow and adapted
                //https://stackoverflow.com/questions/5442183/using-the-animated-circle-in-an-imageview-while-loading-stuff
                //WSBT
                //https://stackoverflow.com/users/1032613/wsbt
                prgLoad.visibility = View.GONE
                text.text = "Click on a bird to add it to your observation list."
            }
        }
        catch(e:Exception){
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        try{
            super.onDestroy()
            coroutineScope.cancel()
            // Release MediaPlayer when the fragment is being destroyed
            mediaPlayer.release()
        }
        catch (e:Exception){
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }
}