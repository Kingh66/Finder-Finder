package com.birdview.models

data class TripCard(val id: String?, val name: String?, val date: Long?, val speciesCount: Int?, val observationsCount: Int?)
