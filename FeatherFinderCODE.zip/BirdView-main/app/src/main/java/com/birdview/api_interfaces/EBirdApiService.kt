package com.birdview.api_interfaces

import com.birdview.models.Bird
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface EBirdApiService {
    @GET("data/obs/geo/recent")
    fun getBirdObservations(
        @Query("lat") latitude: Double,
        @Query("lng") longitude: Double,
        @Query("dist") distanceKm: Int = 50, // Optional: Default to 50km
        @Query("maxResults") maxResults: Int = 10, // Optional: Default to 10 results
        @Query("back") back: Int = 30, // Optional: Default to 30 days of data
        @Query("fmt") format: String = "json", // JSON format
        @Header("X-eBirdApiToken") apiKey: String // Pass API Key in header
    ): Call<List<Bird>>
}
