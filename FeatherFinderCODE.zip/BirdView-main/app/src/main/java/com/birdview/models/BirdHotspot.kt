package com.birdview.models
data class BirdHotspot(
    var latitude: Double? = null,
    var longitude: Double? = null,
    var locationName: String? = null
)
