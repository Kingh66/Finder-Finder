package com.birdview.api_interfaces

import com.birdview.models.BirdHotspot
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Url

interface HotspotsApiInterface {
    @GET
    suspend fun getHotspot(@Url url: String): Response<List<BirdHotspot>> // Replace HotspotResponse with your actual data class
}
